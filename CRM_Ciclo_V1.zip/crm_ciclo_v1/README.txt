CRM CICLO V1

MVP local funcional. Abre index.html en Chrome/Edge/Firefox.

FUNCIONES
- Dashboard
- Alta/edicion de clientas
- Historial menstrual
- Estimacion de proxima menstruacion
- Estimacion de ovulacion
- Ventana fertil estimada
- Confianza basica
- Calendario
- Exportacion/importacion JSON
- Eliminacion de registros

DATOS
La V1 usa localStorage: los datos permanecen en el navegador/dispositivo y no se envian a un servidor.
Para datos reales se recomienda migrar antes a backend seguro con autenticacion, control de acceso, cifrado y auditoria.

FORMULA V1
Con al menos dos inicios validos:
1) duracion de cada ciclo = diferencia entre inicios consecutivos
2) ciclo estimado = promedio de duraciones validas
3) proxima menstruacion ~= ultimo inicio + ciclo estimado
4) ovulacion estimada ~= proxima menstruacion - 14 dias
5) ventana fertil estimada alrededor de la ovulacion

IMPORTANTE
Usar solo con clientas adultas. Las fechas son estimaciones, no diagnosticos ni un metodo anticonceptivo.
